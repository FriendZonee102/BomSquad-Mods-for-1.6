#made by savio enjoy
from ba import *
    
def main() -> None:
    Activity.slow_motion = True

# ba_meta require api 6
# ba_meta export plugin
class slowMo(Plugin):
    def on_app_launch(self) -> None:
        main()