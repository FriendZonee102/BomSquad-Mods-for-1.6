"""
Game Modes manager | Helps to Manage Game-Modes like plugins
I apreciate any kind of modification. So feel free to use or edit code or change credit string.... no problem.

New 2.0:
    New Informatin button for Game mode - shows author, game name, description
    Clean code (beginer friendly)
    Litte bugs patches
    Chnaged position for Extra Game-Modes button to bottom

really awsome servers:
    BCS - https://discord.gg/2RKd9QQdQY
    BOMBSPOT - https://discord.gg/ucyaesh
    CYCLONES - https://discord.gg/pJXxkbQ7kH
"""
from __future__ import annotations

__author__ = 'pranav1711'
__version__ = 2.0

from typing import TYPE_CHECKING
from bastd.ui.confirm import ConfirmWindow
from bastd.ui.settings.advanced import AdvancedSettingsWindow

import ba
import _ba

if TYPE_CHECKING:
    from typing import Any, Type, List, Dict, Tuple, Union, Sequence, Optional


CONFIG = "GamesManager"
APPCONFIG = ba.app.config
BUILD = 20327

WHITE = (0.6, 0.6, 0.6)
RED = (1, 0, 0)
GREEN = (0, 1, 0)
BROWN = (1, 0.40, 0.30)


def notify_client(message: str, color: tuple, sound: str = 'gunCocking') -> None:
    """Notifying client by simple screen message with sounds


    Args:
        message (str): message to display
        color (int): color (R, G, B)
        sound (str): name of sound to play
    """
    ba.screenmessage(
        message=message,
        color=color
    )
    ba.playsound(
        ba.getsound(name=sound))


def update_dict(dictionary: dict, update: any) -> None:
    """Update values in dictionary (ba.app.config)

    Args:

        dictionary (dict): dictionary name
        update (any): update's or change's to make
    """
    if update is None or update == {}:
        return
    APPCONFIG[CONFIG][dictionary] = update
    ba.app.config.commit()


def get_ingame_and_new_gametype() -> tuple:
    """Return's  game-mode objects

    Returns:

        ingame_game_types (list): default game-modes in the game
        new_game_types (list): new game modes from metascan
    """
    ingame_game_types = []
    new_game_types = []

    for game in _ba.app.meta.old_get_game_types():
        if game.__module__.startswith("bastd.game"):
            ingame_game_types.append(game)
        else:
            new_game_types.append(game)

    return (ingame_game_types, new_game_types)


def new_get_meta_game_types() -> list:
    """Overwriting -> ba.app.meta.get_game_types
       Add's enbaled game-modes in game

    Returns:

        final_game_types (list): total game-modes including ingame game-modes and enabled game types
    """
    final_game_types = get_ingame_and_new_gametype()[0]

    for new_game in get_ingame_and_new_gametype()[1]:
        if APPCONFIG[CONFIG][new_game.__name__] == True:
            final_game_types.append(new_game)

    return final_game_types


def set_default_configs() -> None:
    """
    Set configs for this plugin.
    Search new game types and notify the client.
    """
    if CONFIG in APPCONFIG:
        pass
    else:
        APPCONFIG[CONFIG] = {}

    for game in get_ingame_and_new_gametype()[1]:
        if game.__name__ in APPCONFIG[CONFIG]:
            pass

        else:
            APPCONFIG[CONFIG][game.__name__] = False
            notify_client(message=f"Ditected new game-mode, To Enable {game.__name__}\ncheak out extra game-modes in settings",
                          color=GREEN,
                          sound="ding")
    ba.app.config.commit()


# ba_meta require api 6
# ba_meta export plugin
class Plugin(ba.Plugin):
    def on_app_launch(self) -> None:
        """
        Main class, this plugin's root stuf.
        Get the build number so we can get version of game.

        """
        if _ba.env().get('build_number', 0) >= BUILD:
            ba.timer(2, self.wait_and_call)
        else:
            print(__name__, 'works for 1.5 or higher')

    def wait_and_call(self) -> None:
        """
        this function overwrites internal functions.
        to complete meta-scan and get gametypes related to our mod we have to wait until meta scan.

        """
        _ba.app.meta.old_get_game_types = _ba.app.meta.get_game_types
        set_default_configs()
        _ba.app.meta.get_game_types = new_get_meta_game_types
        AdvancedSettingsWindow._rebuild = new_rebuild


# get the copy of original rebuild function so we can use it even we do oveewrite it.
rebuild = AdvancedSettingsWindow._rebuild


def new_rebuild(self, *args, **kwargs):
    """
    original_rebuild -> AdvancedSettingsWindow._rebuild
    adding 'Extra Game-Modes' btn in game settings-advance

    Beacuse this fucntion is from settings.advance, its looped for real-time language update
    so we have to add some extra prevention to privent the repeation for this button
    otherwise it will make copies per second of button.
    """
    available_languages = ba.app.lang.available_languages

    if self._menu_open or (
        self._prev_lang == _ba.app.config.get(
            'Lang', None) and self._prev_lang_list == available_languages):
        return

    uiscale = ba.app.ui.uiscale
    extra_x = 40 if uiscale is ba.UIScale.SMALL else 0

    self._sub_height += 25  # for adding extra space for button
    rebuild(self, *args, **kwargs)  # run the original rebuild

    height = self._sub_height - 35
    height -= 900

    this_button_width = 410

    extra_game_modes_btn = ba.buttonwidget(
        parent=self._subcontainer,
        position=(self._sub_width / 2 - this_button_width / 2, height - 14 - extra_x),
        size=(this_button_width, 60),
        autoselect=True,
        label="Extra Game-Modes",
        text_scale=1.0,
        on_activate_call=ba.Call(
            launch_games_manager_window, self))


def launch_games_manager_window(self):
    """Call's the ManagerWindow class exiting the privous window"""
    ba.containerwidget(
        edit=self._root_widget,
        transition='out_scale')
    ba.app.ui.set_main_menu_window(
        ManagerWindom(
            transition='in_right').get_root_widget())


class ManagerWindom(ba.Window):
    def __init__(self,
                 transition: Optional[str] = 'in_right') -> None:

        uiscale = ba.app.ui.uiscale
        self._width = 870.0 if uiscale is ba.UIScale.SMALL else 670.0
        self._height = (390.0 if uiscale is ba.UIScale.SMALL else
                        450.0 if uiscale is ba.UIScale.MEDIUM else 520.0)
        extra_x = 100 if uiscale is ba.UIScale.SMALL else 0
        self.extra_x = extra_x
        top_extra = 20 if uiscale is ba.UIScale.SMALL else 0

        self._scroll_width = self._width - (100 + 2 * extra_x)
        self._scroll_height = self._height - 115.0
        self._sub_width = self._scroll_width * 0.95
        self._sub_height = 70.0
        self._spacing = 32
        self._extra_button_spacing = self._spacing * 2.5

        super().__init__(
            root_widget=ba.containerwidget(
                size=(self._width, self._height),
                transition=transition,
                scale=(2.06 if uiscale is ba.UIScale.SMALL else
                       1.4 if uiscale is ba.UIScale.MEDIUM else 1.0)))

        self._back_button = ba.buttonwidget(
            parent=self._root_widget,
            autoselect=True,
            position=(52 + self.extra_x,
                      self._height - 60 - top_extra),
            size=(60, 60),
            scale=0.8,
            label=ba.charstr(ba.SpecialChar.BACK),
            button_type='backSmall',
            on_activate_call=self._back)
        ba.containerwidget(edit=self._root_widget,
                           cancel_button=self._back_button)

        self._title_text = ba.textwidget(
            parent=self._root_widget,
            position=(0, self._height - 40 - top_extra),
            size=(self._width, 25),
            text='Game Modes',
            color=ba.app.ui.title_color,
            scale=1.2,
            h_align='center',
            v_align='top')

        self._scrollwidget = ba.scrollwidget(
            parent=self._root_widget,
            position=(50 + extra_x, 50 - top_extra),
            simple_culling_v=20.0,
            highlight=False,
            size=(self._scroll_width,
                  self._scroll_height),
            selection_loops_to_parent=True)
        ba.widget(edit=self._scrollwidget,
                  right_widget=self._scrollwidget)

        self._subcontainer = ba.containerwidget(
            parent=self._scrollwidget,
            size=(self._sub_width,
                  self._sub_height),
            background=False,
            selection_loops_to_parent=True)

        v = self._sub_height - 35
        v -= self._spacing * 1.2
        new_game_types = get_ingame_and_new_gametype()[1]

        for game in new_game_types:
            enbaled = APPCONFIG[CONFIG][game.__name__]
            ba.checkboxwidget(
                parent=self._subcontainer,
                position=(10, v),
                text=game.get_display_string(),
                value=APPCONFIG[CONFIG][game.__name__],
                maxwidth=self._scroll_width - 100,
                size=(self._scroll_width - 10, 70),
                on_value_change_call=ba.Call(
                    self.change, game),
                scale=1.25,
                textcolor=GREEN if enbaled else
                WHITE)

            ba.buttonwidget(
                parent=self._subcontainer,
                autoselect=True,
                label='?',
                color=BROWN,
                position=(500, v + 30),
                size=(20, 20),
                scale=1,
                on_activate_call=ba.Call(
                    self.inform_window, game))

            self._sub_height += 60
            v -= 60

    def change(self, game: str, value: Any) -> None:
        """changes the value of check boxes"""
        try:
            update_dict(game.__name__, value)
            game_name = game.get_display_string().evaluate()
            if value == True:
                notify_client(message=f"Enabled Game-mode {game_name}", color=GREEN)
            else:
                notify_client(message=f"Disabled Game-mode {game_name}", color=WHITE)
        except Exception:
            notify_client(message=f'Some error occured by changing {game}',
                          color=RED,
                          sound='error')

    def inform_window(self, game):
        try:
            if game.author:
                author = game.author
        except Exception:
            author = 'Unkwon'

        ConfirmWindow(
            text=f'Author: {author}\nGame: {game.get_display_string().evaluate()}\n{game.description}',
            width=360.0,
            height=130.0,
            cancel_button=False,
            color=(1, 1, 1),
            text_scale=1.0
        )

    def _back(self) -> None:
        """kill the window with transition and get back to previous window"""
        ba.containerwidget(edit=self._root_widget, transition='out_scale')
        ba.app.ui.set_main_menu_window(
            AdvancedSettingsWindow(
                transition='in_left').get_root_widget())
